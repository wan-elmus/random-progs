

betweenThreeAndFour :: [Float] -> [Float]
betweenThreeAndFour = filter (\x -> x >= 3.0 && x <= 4.0)

